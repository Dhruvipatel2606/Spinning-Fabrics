package com.example.spinningfabrics.Customer;

import static com.example.spinningfabrics.Constant.COTTON;
import static com.example.spinningfabrics.Constant.PRODUCT;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.spinningfabrics.Adapter.ProductAdapter;
import com.example.spinningfabrics.Model.ProductModel;
import com.example.spinningfabrics.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Objects;

import io.paperdb.Paper;

public class product_cotton extends AppCompatActivity {

    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    RecyclerView rvCotton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_cotton);
        firebaseDatabase = FirebaseDatabase.getInstance();
        rvCotton = findViewById(R.id.rvCotton);
        getProduct();
        Paper.init(this);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(product_cotton.this, R.color.white));
        }
        Objects.requireNonNull(getSupportActionBar()).hide();
    }

    private void getProduct() {

        ArrayList<ProductModel> cottonList = new ArrayList<>();
        databaseReference = firebaseDatabase.getReference(PRODUCT).child(COTTON);
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                cottonList.clear();
                for (DataSnapshot snapshot1 : snapshot.getChildren()) {
                    if (snapshot1 != null) {
                        ProductModel model = snapshot1.getValue(ProductModel.class);
                        if (model != null) {
                            cottonList.add(new ProductModel(model.getImg(), model.getMaterial(), model.getName(), model.getPrice(), model.getQty(), model.getSellerName()));
                        }
                    }
                }

                LinearLayoutManager manager = new LinearLayoutManager(product_cotton.this);
                ProductAdapter adapter = new ProductAdapter(product_cotton.this, cottonList);
                rvCotton.setLayoutManager(manager);
                rvCotton.setAdapter(adapter);
                adapter.notifyDataSetChanged();
                Toast.makeText(product_cotton.this, "data added", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(product_cotton.this, "Fail to add data " + error, Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void home(View view) {
        finish();
    }

    public void cart(View view) {
        Intent cart = new Intent(getApplicationContext(), cart.class);
        startActivity(cart);
    }

    public void wish(View view) {
        Intent w = new Intent(getApplicationContext(), wishlist.class);
        startActivity(w);
    }
}