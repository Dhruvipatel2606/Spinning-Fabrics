package com.example.spinningfabrics.Customer;


import static com.example.spinningfabrics.Constant.REGISTER_MODEL;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.spinningfabrics.Model.RegisterModel;
import com.example.spinningfabrics.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Objects;

import io.paperdb.Paper;

public class profile extends AppCompatActivity {

    FirebaseDatabase firebaseDatabase;

    DatabaseReference databaseReference;

    EditText cusername, cname, cemail, cphone, cadd;
    Button save;
    String state,city,pass;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(profile.this, R.color.white));
        }
        Paper.init(this);

        firebaseDatabase = FirebaseDatabase.getInstance();

        getdata();

        Objects.requireNonNull(getSupportActionBar()).hide();
        cusername = findViewById(R.id.c_username);
        cname = findViewById(R.id.c_name);
        cemail = findViewById(R.id.c_email);
        cphone = findViewById(R.id.c_phone);
        cadd = findViewById(R.id.c_add);
        save = findViewById(R.id.save);

        cphone.setEnabled(false);
        cemail.setEnabled(false);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String uname, name, email, phone, add;
                uname = cusername.getText().toString();
                name = cname.getText().toString();
                email = cemail.getText().toString();
                phone = cphone.getText().toString();
                add = cadd.getText().toString();
                RegisterModel model = new RegisterModel();
                model.setName(name);
                model.setUserName(uname);
                model.setEmail(email);
                model.setAddress(add);
                model.setPhone(phone);
                model.setState(state);
                model.setCity(city);
                model.setPass(pass);

                databaseReference = firebaseDatabase.getReference(REGISTER_MODEL).child(Paper.book().read("phone").toString());
                databaseReference.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        databaseReference.setValue(model);
                        Toast.makeText(profile.this, "detail save successfully", Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
//                Toast.makeText(profile.this, "Fail to get data.", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

    }

    public void getdata() {

        databaseReference = firebaseDatabase.getReference(REGISTER_MODEL).child(Paper.book().read("phone").toString());

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                RegisterModel model = snapshot.getValue(RegisterModel.class);
                if (model != null) {
                    cusername.setText(model.getUserName());
                    cemail.setText(model.getEmail());
                    cphone.setText(model.getPhone());
                    cadd.setText(model.getAddress());
                    cname.setText(model.getName());
                    state = model.getState();
                    pass = model.getPass();
                    city = model.getCity();

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
//                Toast.makeText(profile.this, "Fail to get data.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void profile_back(View view) {
        finish();
    }


    public void home(View view) {
        FirebaseAuth.getInstance().signOut();
        Intent home = new Intent(getApplicationContext(), com.example.spinningfabrics.home.class);
        startActivity(home);

    }

    public void cart(View view) {
        Intent cart = new Intent(getApplicationContext(), cart.class);
        startActivity(cart);

    }

    public void wish(View view) {
        Intent w = new Intent(getApplicationContext(), wishlist.class);
        startActivity(w);

    }
}