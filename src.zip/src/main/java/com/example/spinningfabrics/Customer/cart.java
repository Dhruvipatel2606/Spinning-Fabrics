package com.example.spinningfabrics.Customer;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;

import com.example.spinningfabrics.R;

import java.util.ArrayList;
import java.util.Objects;

public class cart extends AppCompatActivity {
    RecyclerView recyclerView;
    ArrayList<String> customer=new ArrayList<>();
    //customerAdapter adapter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(cart.this,R.color.white));
        }
        Objects.requireNonNull(getSupportActionBar()).hide();
        recyclerView=findViewById(R.id.rv_cart);
    }
    public void cart_back(View view)
    {
//        Intent back = new Intent(getApplicationContext(), Gallery.class);
//        startActivity(back);
        finish();
    }
    public void wish(View view)
    {
        Intent w = new Intent(getApplicationContext(),wishlist.class);
        startActivity(w);
    }
}