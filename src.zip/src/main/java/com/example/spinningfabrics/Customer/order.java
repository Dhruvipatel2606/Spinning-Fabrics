package com.example.spinningfabrics.Customer;

import static com.example.spinningfabrics.Constant.PRODUCT;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.example.spinningfabrics.Model.ProductModel;
import com.example.spinningfabrics.R;
import com.example.spinningfabrics.databinding.ActivityOrderBinding;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Objects;

import io.paperdb.Paper;

public class order extends AppCompatActivity {

    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    ActivityOrderBinding binding;
    String name,pqty,Price;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order);
        binding = ActivityOrderBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        Paper.init(this);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(order.this, R.color.sf));
        }
        Objects.requireNonNull(getSupportActionBar()).hide();

        firebaseDatabase = FirebaseDatabase.getInstance();
//        Intent intent = getIntent();
//        String name = intent.getStringExtra("name");
//        String material = intent.getStringExtra("material");


//        Intent ProductInt = getIntent();
//        String qty = ProductInt.getStringExtra("Qty");
        getData();



    }



    private void getData() {

        databaseReference = firebaseDatabase.getReference(PRODUCT);
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                ProductModel model = snapshot.getValue(ProductModel.class);
                if (model != null) {

                    Intent intent=getIntent();
                    name = intent.getStringExtra("Name");
                    pqty=intent.getStringExtra("PQty");
                    Price=intent.getStringExtra("Price");
                    binding.orderprice.setText(""+Price);
                    binding.orderqty.setText("Quantity : "+pqty);
                    binding.materialname.setText("Material Name: "+name);
                    binding.addname.setText("Address : "+Paper.book().read("User_Add"));
                    binding.nameuser.setText("Name : "+Paper.book().read("User_Name"));
                    binding.userphone.setText("Phone : "+Paper.book().read("phone"));

                    Glide.with(order.this).load(intent.getStringExtra("img")).into(binding.productimage);
                    binding.orderrate.setText(Price+"*"+pqty);
                    int pr,qt;
                    pr= Integer.parseInt(Price);
                   // Log.d("TAG","onDataChange ====>" + " Price: "+Price);
                    qt = Integer.parseInt(pqty);
                    int mul;
                    mul = pr*qt;
                    binding.orderamt.setText(""+mul);
                    binding.orderamt2.setText("₹"+mul);


                    //binding.deliver.setText(Paper.book().read("User_Add"));
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(order.this, "Fail to add data " + error, Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void orderback(View view) {
        finish();
//        Intent order = new Intent(getApplicationContext(), Gallery.class);
//        startActivity(order);
    }

    public void con(View view) {
        finish();
        Intent con = new Intent(getApplicationContext(), payment.class);
        String mu = binding.orderamt.getText().toString();
        con.putExtra("MULTI",mu);
        startActivity(con);
    }
}