package com.example.spinningfabrics.Customer;

import static com.example.spinningfabrics.Constant.PRODUCT;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.example.spinningfabrics.Model.ProductModel;
import com.example.spinningfabrics.R;
import com.example.spinningfabrics.databinding.ActivityProductPageBinding;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Objects;

import io.paperdb.Paper;

public class product_page extends AppCompatActivity {
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    ActivityProductPageBinding binding;
    //public static String qty;
    EditText qty;
    Button add,remove;
    TextView price;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityProductPageBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        Paper.init(this);

        qty=findViewById(R.id.qty);
        price = findViewById(R.id.pprice);


        binding.imageButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        firebaseDatabase = FirebaseDatabase.getInstance();
        Intent intent = getIntent();
        String name = intent.getStringExtra("name");
        String material = intent.getStringExtra("material");

        getData(name, material);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(product_page.this, R.color.white));
        }
        Objects.requireNonNull(getSupportActionBar()).hide();
    }

    String imgUrl;
    private void getData(String name, String material) {
        databaseReference = firebaseDatabase.getReference(PRODUCT).child(material).child(name);
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                ProductModel model = snapshot.getValue(ProductModel.class);
                if (model != null) {
                    binding.pname.setText("Name : "+model.getName());
                    binding.pmaterial.setText("Material : "+model.getMaterial());
                    binding.pprice.setText(model.getPrice());
                    imgUrl = model.getImg();
                    Glide.with(product_page.this).load(model.getImg()).into(binding.pImg);
                    binding.deliver.setText(Paper.book().read("User_Add"));
//                    PRICE = model.getPrice();
//                    Paper.book().write("PRICE",model.getPrice());
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(product_page.this, "Fail to add data " + error, Toast.LENGTH_SHORT).show();
            }
        });
    }


    public void cart(View view) {
        Intent cart = new Intent(getApplicationContext(), com.example.spinningfabrics.Customer.cart.class);
        startActivity(cart);
    }

    public void wish(View view) {
        Intent w = new Intent(getApplicationContext(), wishlist.class);
        startActivity(w);
    }

    public void BuyNow(View view) {
        Intent intent = getIntent();
        String Price = price.getText().toString();
        String name = intent.getStringExtra("name");
        String material = intent.getStringExtra("material");
        Intent BuyNow = new Intent(getApplicationContext(), order.class);
        String Qty=qty.getText().toString();
        BuyNow.putExtra("Name",name);
        BuyNow.putExtra("Price",Price);
        BuyNow.putExtra("Material",material);
        BuyNow.putExtra("PQty",Qty);
        BuyNow.putExtra("img",imgUrl);
        startActivity(BuyNow);
    }

}