package com.example.spinningfabrics.Customer;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.spinningfabrics.Model.RegisterModel;
import com.example.spinningfabrics.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Objects;

import io.paperdb.Paper;

public class C_Register extends AppCompatActivity {
Button CTologin;
EditText CUserR,CEmailR,CPassR,CCPassR,CAddR,CCityR,CStateR,CPhoneR,Cname;
ProgressDialog loadingbar;

    FirebaseAuth auth;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    public static String user_number,User_Add,User_Name;

    RegisterModel model;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cregister);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(this,R.color.sf));
        }
        Objects.requireNonNull(getSupportActionBar()).hide();
        auth=FirebaseAuth.getInstance();
        // instance of our Firebase database.
        firebaseDatabase = FirebaseDatabase.getInstance();
        Paper.init(this);
        // below line is used to get reference for our database.




        CTologin=findViewById(R.id.C_Register_btn);
        CUserR=findViewById(R.id.C_User_R);
        CEmailR=findViewById(R.id.C_Email_R);
        CPassR=findViewById(R.id.C_Pass_R);
        CCPassR=findViewById(R.id.C_CPass_R);
        CAddR=findViewById(R.id.C_Add_R_);
        CCityR=findViewById(R.id.C_City_R);
        CStateR=findViewById(R.id.C_State_R);
        CPhoneR=findViewById(R.id.C_Phone_R);
        Cname=findViewById(R.id.C_name);
        loadingbar=new ProgressDialog(this);
        CTologin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createAccount();
            }

            private void createAccount() {
                String cuser=CUserR.getText().toString().trim();
                String cname=Cname.getText().toString().trim();
                String cemail=CEmailR.getText().toString().trim();
                String cpass=CPassR.getText().toString().trim();
                String ccpass=CCPassR.getText().toString().trim();
                String cadd=CAddR.getText().toString().trim();
                String ccity=CCityR.getText().toString().trim();
                String cstate=CStateR.getText().toString().trim();
                String cphone=CPhoneR.getText().toString().trim();


                if(TextUtils.isEmpty(cuser))
                {
                    CUserR.setError("Please enter your username");
                    //Toast.makeText(C_Register.this, "Please enter your username", Toast.LENGTH_LONG).show();
                }
                else if(TextUtils.isEmpty(cemail))
                {
                    CEmailR.setError("Please enter your email id");
                   //Toast.makeText(C_Register.this, "Please enter your email id", Toast.LENGTH_LONG).show();
                }
                else if(TextUtils.isEmpty(cpass))
                {
                    CPassR.setError("Please enter your password");
                    //Toast.makeText(C_Register.this, "Please enter your password", Toast.LENGTH_LONG).show();
                }
                else if(TextUtils.isEmpty(ccpass))
                {
                    CCPassR.setError("Please enter your confirm password");
                    //Toast.makeText(C_Register.this, "Please enter your confirm password", Toast.LENGTH_LONG).show();
                }
                else if(TextUtils.isEmpty(cadd))
                {
                    CAddR.setError("Please enter your address");
                    //Toast.makeText(C_Register.this, "Please enter your address", Toast.LENGTH_LONG).show();
                }
                else if(TextUtils.isEmpty(ccity))
                {
                    CCityR.setError("Please enter your city");
                    //Toast.makeText(C_Register.this, "Please enter your city", Toast.LENGTH_LONG).show();
                }
                else if(TextUtils.isEmpty(cstate))
                {
                    CStateR.setError("Please enter your state");
                    //Toast.makeText(C_Register.this, "Please enter your state", Toast.LENGTH_LONG).show();
                }
                else if(TextUtils.isEmpty(cphone))
                {
                    CPhoneR.setError("Please enter your phone number");
                    //Toast.makeText(C_Register.this, "Please enter your phone number", Toast.LENGTH_LONG).show();
                }
                else if(TextUtils.isEmpty(cname))
                {
                    Cname.setError("Please enter your name");
                    //Toast.makeText(C_Register.this, "Please enter your name", Toast.LENGTH_LONG).show();
                }
                else
                {

                    model = new RegisterModel();
                    model.setName(cname);
                    model.setUserName(cuser);
                    model.setEmail(cemail);
                    model.setPass(cpass);
                    model.setAddress(cadd);
                    model.setState(cstate);
                    model.setCity(ccity);
                    model.setPhone(cphone);


                    loadingbar.setTitle("Register Your Account");
                    loadingbar.setMessage("Please wait,while we are checking the credentials ");
                    loadingbar.setCanceledOnTouchOutside(false);
                    loadingbar.show();

                    auth.createUserWithEmailAndPassword(cemail,cpass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful())
                        {
                            Toast.makeText(C_Register.this, "Registration Successful ", Toast.LENGTH_LONG).show();
                            user_number = model.getPhone();
                            Paper.book().write("phone",model.getPhone());
                            User_Add = model.getAddress();
                            Paper.book().write("User_Add",model.getAddress());
                            User_Name = model.getName();
                            Paper.book().write("User_Name",model.getName());


                            addDataToFireBase(model);
                            Intent i=new Intent(getApplicationContext(),C_Login.class);
                            startActivity(i);
                            finish();
                        }
                        else
                        {
                            Toast.makeText(C_Register.this, "Registration Failed!!"+ Objects.requireNonNull(task.getException()).getMessage(), Toast.LENGTH_LONG).show();
                        }
                    }
                });

                }
            }

        });

    }

    private void addDataToFireBase(RegisterModel model) {
        databaseReference = firebaseDatabase.getReference("RegisterModel").child(user_number);
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                databaseReference.setValue(model);
                Toast.makeText(C_Register.this, "data added", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(C_Register.this, "Fail to add data " + error, Toast.LENGTH_SHORT).show();
            }
        });
    }

}