package com.example.spinningfabrics.Customer;

import static com.example.spinningfabrics.Constant.CHIFFON;
import static com.example.spinningfabrics.Constant.PRODUCT;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.spinningfabrics.Adapter.ProductAdapter;
import com.example.spinningfabrics.Model.ProductModel;
import com.example.spinningfabrics.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Objects;

public class product_chiffon extends AppCompatActivity {

    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    RecyclerView rvChiffon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_chiffon);
        firebaseDatabase = FirebaseDatabase.getInstance();
        rvChiffon = findViewById(R.id.rvChiffon);
        getProduct();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(product_chiffon.this, R.color.white));
        }
        Objects.requireNonNull(getSupportActionBar()).hide();
    }

    private void getProduct() {

        ArrayList<ProductModel> chiffonList = new ArrayList<>();
        databaseReference = firebaseDatabase.getReference(PRODUCT).child(CHIFFON);
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                chiffonList.clear();
                for (DataSnapshot snapshot1 : snapshot.getChildren()) {
                    if (snapshot1 != null) {
                        ProductModel model = snapshot1.getValue(ProductModel.class);
                        if (model != null) {
                            chiffonList.add(new ProductModel(model.getImg(), model.getMaterial(), model.getName(), model.getPrice(), model.getQty(), model.getSellerName()));
                        }
                    }
                }

                LinearLayoutManager manager = new LinearLayoutManager(product_chiffon.this);
                ProductAdapter adapter = new ProductAdapter(product_chiffon.this, chiffonList);
                rvChiffon.setLayoutManager(manager);
                rvChiffon.setAdapter(adapter);
                adapter.notifyDataSetChanged();
                Toast.makeText(product_chiffon.this, "data added", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(product_chiffon.this, "Fail to add data " + error, Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void home(View view) {
        finish();
    }

    public void cart(View view) {
        Intent cart = new Intent(getApplicationContext(), cart.class);
        startActivity(cart);
    }

    public void wish(View view) {
        Intent w = new Intent(getApplicationContext(), wishlist.class);
        startActivity(w);
    }
}