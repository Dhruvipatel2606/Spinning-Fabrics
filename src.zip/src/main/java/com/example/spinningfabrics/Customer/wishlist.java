package com.example.spinningfabrics.Customer;

import android.os.Build;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.spinningfabrics.R;

import java.util.Objects;

public class wishlist extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wishlist);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(this,R.color.white));
        }
        Objects.requireNonNull(getSupportActionBar()).hide();
    }
    public void wish_back(View view)
    {
        finish();
//        Intent back = new Intent(getApplicationContext(), Gallery.class);
//        startActivity(back);

    }
}