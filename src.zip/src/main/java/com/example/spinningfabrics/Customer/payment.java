package com.example.spinningfabrics.Customer;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.spinningfabrics.R;

import java.util.Objects;

public class payment extends AppCompatActivity {
    Button confrimbtn;
    TextView pay,total;

    float pr,gst,amt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(payment.this,R.color.sf));
        }
        Objects.requireNonNull(getSupportActionBar()).hide();
        pay = findViewById(R.id.payprice);
        total = findViewById(R.id.payable);


        Intent mul = getIntent();
        String m = mul.getStringExtra("MULTI");
        pay.setText(""+m);

         pr =Float.parseFloat(m);
        Log.d("TAG","onDataChange ====>" + " Price: "+pr);
         gst = (pr*5)/100;
         amt = pr+gst;

        total.setText("₹"+amt);

        confrimbtn=findViewById(R.id.confirmbtn);
        confrimbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(payment.this, "Your order is placed", Toast.LENGTH_LONG).show();
            }
        });


    }

    public void back(View view)
    {
        finish();
    }

}