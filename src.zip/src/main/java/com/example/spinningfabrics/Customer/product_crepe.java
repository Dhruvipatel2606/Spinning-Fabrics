package com.example.spinningfabrics.Customer;

import static com.example.spinningfabrics.Constant.CREPE;
import static com.example.spinningfabrics.Constant.PRODUCT;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.spinningfabrics.Adapter.ProductAdapter;
import com.example.spinningfabrics.Model.ProductModel;
import com.example.spinningfabrics.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Objects;

import io.paperdb.Paper;

public class product_crepe extends AppCompatActivity {

    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    RecyclerView rvCrepe;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_crepe);
        firebaseDatabase = FirebaseDatabase.getInstance();
        rvCrepe = findViewById(R.id.rvCrepe);
        getProduct();
        Paper.init(this);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(product_crepe.this, R.color.white));
        }
        Objects.requireNonNull(getSupportActionBar()).hide();
    }

    private void getProduct() {

        ArrayList<ProductModel> crepeList = new ArrayList<>();
        databaseReference = firebaseDatabase.getReference(PRODUCT).child(CREPE);
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                crepeList.clear();
                for (DataSnapshot snapshot1 : snapshot.getChildren()) {
                    if (snapshot1 != null) {
                        ProductModel model = snapshot1.getValue(ProductModel.class);
                        if (model != null) {
                            crepeList.add(new ProductModel(model.getImg(), model.getMaterial(), model.getName(), model.getPrice(), model.getQty(), model.getSellerName()));
                        }
                    }
                }

                LinearLayoutManager manager = new LinearLayoutManager(product_crepe.this);
                ProductAdapter adapter = new ProductAdapter(product_crepe.this, crepeList);
                rvCrepe.setLayoutManager(manager);
                rvCrepe.setAdapter(adapter);
                adapter.notifyDataSetChanged();
                Toast.makeText(product_crepe.this, "data added", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(product_crepe.this, "Fail to add data " + error, Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void home(View view) {
        finish();
    }

    public void cart(View view) {
        Intent cart = new Intent(getApplicationContext(), cart.class);
        startActivity(cart);
    }

    public void wish(View view) {
        Intent w = new Intent(getApplicationContext(), wishlist.class);
        startActivity(w);
    }
}