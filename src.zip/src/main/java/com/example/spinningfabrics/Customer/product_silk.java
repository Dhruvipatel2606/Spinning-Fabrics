package com.example.spinningfabrics.Customer;

import static com.example.spinningfabrics.Constant.PRODUCT;
import static com.example.spinningfabrics.Constant.SILK;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.spinningfabrics.Adapter.ProductAdapter;
import com.example.spinningfabrics.Model.ProductModel;
import com.example.spinningfabrics.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Objects;

import io.paperdb.Paper;

public class product_silk extends AppCompatActivity {
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    RecyclerView rvSilk;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_product_silk);
        firebaseDatabase = FirebaseDatabase.getInstance();
        rvSilk = findViewById(R.id.rvSilk);
        Paper.init(this);
        getProduct();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(product_silk.this, R.color.white));
        }
        Objects.requireNonNull(getSupportActionBar()).hide();
    }

    private void getProduct() {
        ArrayList<ProductModel> silkList = new ArrayList<>();
        databaseReference = firebaseDatabase.getReference(PRODUCT).child(SILK);
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                silkList.clear();
                for (DataSnapshot snapshot1 : snapshot.getChildren()) {
                    if (snapshot1 != null) {
                        ProductModel model = snapshot1.getValue(ProductModel.class);
                        if (model != null) {
                            silkList.add(new ProductModel(model.getImg(),  model.getMaterial(),  model.getName(), model.getPrice(), model.getQty(),model.getSellerName()));
                           // Log.d("TAG", "onDataChange: ====> name : "+ Paper.book().read("sellerName").toString());
                        }
                    }
                }

                LinearLayoutManager manager = new LinearLayoutManager(product_silk.this);
                ProductAdapter adapter = new ProductAdapter(product_silk.this, silkList);
                rvSilk.setLayoutManager(manager);
                rvSilk.setAdapter(adapter);
                adapter.notifyDataSetChanged();
                Toast.makeText(product_silk.this, "data added", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(product_silk.this, "Fail to add data " + error, Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void home(View view) {
        finish();
    }

    public void cart(View view) {
        Intent cart = new Intent(getApplicationContext(), cart.class);
        startActivity(cart);
    }

    public void wish(View view) {
        Intent w = new Intent(getApplicationContext(), wishlist.class);
        startActivity(w);
    }
}