package com.example.spinningfabrics.Customer;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import com.example.spinningfabrics.R;
import com.example.spinningfabrics.home;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;

import java.util.Objects;

public class Gallery extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    ImageButton img;
    DrawerLayout drawerLayout;
    NavigationView navigationView;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gallery);

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                getWindow().setStatusBarColor(ContextCompat.getColor(Gallery.this,R.color.white));
            }
        Objects.requireNonNull(getSupportActionBar()).hide();
            img=findViewById(R.id.menu);
            drawerLayout=findViewById(R.id.drawable_layout);
            navigationView=findViewById(R.id.navigation_view);
            navigationDrawer();

    }

    private void navigationDrawer() {
        navigationView.bringToFront();
        navigationView.setNavigationItemSelectedListener(this);

        img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (drawerLayout.isDrawerVisible(GravityCompat.START)){
                    drawerLayout.closeDrawer(GravityCompat.START);
                }
                else {
                    drawerLayout.openDrawer(GravityCompat.START);
                }
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerVisible(GravityCompat.START)){
            drawerLayout.closeDrawer(GravityCompat.START);
        }
        else {
            super.onBackPressed();
        }
    }

    public void Silk(View view)
    {
        Intent silk = new Intent(getApplicationContext(), product_silk.class);
        startActivity(silk);
    }

    public void Chiffon(View view)
    {
        Intent chiffon = new Intent(getApplicationContext(), product_chiffon.class);
        startActivity(chiffon);
    }

    public void Cotton(View view)
    {
        Intent cotton = new Intent(getApplicationContext(), product_cotton.class);
        startActivity(cotton);
    }

    public void Crepe(View view)
    {
        Intent crepe = new Intent(getApplicationContext(), product_crepe.class);
        startActivity(crepe);
    }

    public void Linen(View view)
    {
        Intent linen = new Intent(getApplicationContext(), product_linen.class);
        startActivity(linen);
    }

    public void Georgette(View view)
    {
        Intent georgette = new Intent(getApplicationContext(), product_georgette.class);
        startActivity(georgette);
    }

    public void Scrap(View view)
    {
        Intent scrap = new Intent(getApplicationContext(), product_scrap.class);
        startActivity(scrap);
    }

    public void Organic(View view)
    {
        Intent organic = new Intent(getApplicationContext(),product_organic.class);
        startActivity(organic);
    }

    public void profile(View view)
    {
        Intent profile = new Intent(getApplicationContext(), com.example.spinningfabrics.Customer.profile.class);
        startActivity(profile);
    }


    public void cart(View view)
    {
        Intent cart = new Intent(getApplicationContext(), com.example.spinningfabrics.Customer.cart.class);
        startActivity(cart);
    }


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId())
        {
            case  R.id.myOrder:
                Toast.makeText(this, "My Order Selected", Toast.LENGTH_LONG).show();
                Intent order=new Intent(getApplicationContext(), com.example.spinningfabrics.Customer.order.class);
                startActivity(order);
                break;
            case  R.id.Cart:
                Toast.makeText(this, "My Cart Selected", Toast.LENGTH_LONG).show();
                Intent cart=new Intent(getApplicationContext(),cart.class);
                startActivity(cart);
                break;
            case  R.id.wishlist:
                Toast.makeText(this, "My Wishlist Selected", Toast.LENGTH_LONG).show();
                Intent wish=new Intent(getApplicationContext(), wishlist.class);
                startActivity(wish);
                break;
            case  R.id.account:
                Toast.makeText(this, "My Account Selected", Toast.LENGTH_LONG).show();
                Intent acc=new Intent(getApplicationContext(),profile.class);
                startActivity(acc);
                break;
            case  R.id.c_logout:
                Toast.makeText(this, "Logout Selected", Toast.LENGTH_LONG).show();
                Intent logout=new Intent(getApplicationContext(), home.class);
                FirebaseAuth.getInstance().signOut();
                startActivity(logout);
                break;
        }
        drawerLayout.closeDrawers();
        return true;
    }
}