package com.example.spinningfabrics.Customer;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.spinningfabrics.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import java.util.Objects;

public class C_Login extends AppCompatActivity{

    FirebaseAuth auth;
    TextView CToregister;
    Button Clogin;
    EditText CEmail,CPass;

    @Override
    protected void onResume() {
        super.onResume();

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clogin);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(C_Login.this,R.color.sf));
        }
        Objects.requireNonNull(getSupportActionBar()).hide();
        auth=FirebaseAuth.getInstance();
        CToregister=findViewById(R.id.C_Register);

        CEmail=findViewById(R.id.C_Email);
        CPass=findViewById(R.id.C_Pass);
        Clogin=findViewById(R.id.C_Login);


        Clogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email=CEmail.getText().toString();
                String pass=CPass.getText().toString();

                if(!email.isEmpty() && Patterns.EMAIL_ADDRESS.matcher(email).matches())
                {
                    if(!pass.isEmpty())
                    {

                        loginToUser(email,pass);

                    }
                    else
                    {
                        CPass.setError("Password Cannot be Empty");
                    }
                }
                else if(email.isEmpty())
                {
                    CEmail.setError("Email Cannot be Empty");
                }
                else
                {
                    CEmail.setError("Please Enter Valid Email!!");
                }
            }
        });
    }

    private void loginToUser(String email, String pass) {

        auth.signInWithEmailAndPassword(email, pass).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
            @Override
            public void onSuccess(AuthResult authResult) {
                Toast.makeText(C_Login.this, "Login Sucessful", Toast.LENGTH_SHORT).show();
                Intent in=new Intent(getApplicationContext(),Gallery.class);
                startActivity(in);
                finish();
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(C_Login.this, "Login Failed", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void toregister(View view)
    {
        Intent i=new Intent(getApplicationContext(),C_Register.class);
        startActivity(i);
    }
}