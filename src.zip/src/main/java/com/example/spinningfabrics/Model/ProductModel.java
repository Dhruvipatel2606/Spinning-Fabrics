package com.example.spinningfabrics.Model;

public class ProductModel {
    String name,sellerName,qty,price,material,img,sNumber;

    public ProductModel(String img, String material, String name, String price, String qty, String sellerName) {
        this.name = name;
        this.sellerName = sellerName;
        this.qty = qty;
        this.price = price;
        this.material = material;
        this.img = img;
    }

    public ProductModel( ) {

    }

    public String getsNumber() {
        return sNumber;
    }

    public void setsNumber(String sNumber) {
        this.sNumber = sNumber;
    }

    public String getImg() {
        return img;
    }

    public void setImg(String img) {
        this.img = img;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSellerName() {
        return sellerName;
    }

    public void setSellerName(String sellerName) {
        this.sellerName = sellerName;
    }

    public String getQty() {
        return qty;
    }

    public void setQty(String qty) {
        this.qty = qty;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        this.material = material;
    }
}
