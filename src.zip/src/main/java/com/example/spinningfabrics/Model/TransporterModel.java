package com.example.spinningfabrics.Model;

public class TransporterModel {

    String tUserR,tNameR,tEmailR,tPassR,tCPassR,tPhoneR,tvtypeR,tvnoR,tlnoR;

    public TransporterModel(){

    }

    public TransporterModel(String tUserR, String tNameR, String tEmailR, String tPassR, String tCPassR, String tPhoneR, String tvtypeR, String tvnoR, String tlnoR) {
        this.tUserR = tUserR;
        this.tNameR = tNameR;
        this.tEmailR = tEmailR;
        this.tPassR = tPassR;
        this.tCPassR = tCPassR;
        this.tPhoneR = tPhoneR;
        this.tvtypeR = tvtypeR;
        this.tvnoR = tvnoR;
        this.tlnoR = tlnoR;
    }

    public String gettUserR() {
        return tUserR;
    }

    public void settUserR(String tUserR) {
        this.tUserR = tUserR;
    }

    public String gettNameR() {
        return tNameR;
    }

    public void settNameR(String tNameR) {
        this.tNameR = tNameR;
    }

    public String gettEmailR() {
        return tEmailR;
    }

    public void settEmailR(String tEmailR) {
        this.tEmailR = tEmailR;
    }

    public String gettPassR() {
        return tPassR;
    }

    public void settPassR(String tPassR) {
        this.tPassR = tPassR;
    }

    public String gettCPassR() {
        return tCPassR;
    }

    public void settCPassR(String tCPassR) {
        this.tCPassR = tCPassR;
    }

    public String gettPhoneR() {
        return tPhoneR;
    }

    public void settPhoneR(String tPhoneR) {
        this.tPhoneR = tPhoneR;
    }

    public String getTvtypeR() {
        return tvtypeR;
    }

    public void setTvtypeR(String tvtypeR) {
        this.tvtypeR = tvtypeR;
    }

    public String getTvnoR() {
        return tvnoR;
    }

    public void setTvnoR(String tvnoR) {
        this.tvnoR = tvnoR;
    }

    public String getTlnoR() {
        return tlnoR;
    }

    public void setTlnoR(String tlnoR) {
        this.tlnoR = tlnoR;
    }
}
