package com.example.spinningfabrics.Model;

public class SellerRegisterModel {

    String username,sname,email,pass,shopname,address,gstno, phone;

    public SellerRegisterModel(){

    }

    public SellerRegisterModel(String username, String sname, String email, String pass, String shopname, String address, String gstno, String phone) {
        this.username = username;
        this.sname = sname;
        this.email = email;
        this.pass = pass;
        this.shopname = shopname;
        this.address = address;
        this.gstno = gstno;
        this.phone = phone;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getName() {
        return sname;
    }

    public void setName(String sname) {
        this.sname = sname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public String getShopname() {
        return shopname;
    }

    public void setShopname(String shopname) {
        this.shopname = shopname;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getGstno() {
        return gstno;
    }

    public void setGstno(String gstno) {
        this.gstno = gstno;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
}
