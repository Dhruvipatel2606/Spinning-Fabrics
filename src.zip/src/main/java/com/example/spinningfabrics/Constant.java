package com.example.spinningfabrics;

public class Constant {
    public static String PRODUCT = "Product";
    public static String SILK = "silk";

    public static String CHIFFON = "chiffon";
    public static String COTTON = "cotton";
    public static String CREPE = "crepe";
    public static String GEORGETTE = "georgette";
    public static String LINEN = "linen";
    public static String ORGANIC = "organic";
    public static String SCRAP = "scrap";
    public static String REGISTER_MODEL = "RegisterModel";
    public static String SELLER_REGISTER_MODEL = "SellerRegisterModel";


}
