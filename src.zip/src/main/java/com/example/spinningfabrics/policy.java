package com.example.spinningfabrics;

import android.app.Activity;

public class policy extends Activity {
}
