package com.example.spinningfabrics.Transporter;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.spinningfabrics.Model.ProductModel;
import com.example.spinningfabrics.Model.TransporterModel;
import com.example.spinningfabrics.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Objects;

import io.paperdb.Paper;

public class T_Register extends AppCompatActivity{
    Button register;


    ProgressDialog loadingbar;
    FirebaseDatabase TranspoterfirebaseDatabase;
    DatabaseReference transporterdatabaseReference;

    FirebaseAuth auth;
    TransporterModel Tmodel;
    ProductModel Pmodel;
    EditText TvtypeR,TvnoR,TlnoR;

    public static String tuser_number,tUser_Add,tUser_Name;

    EditText TUserR,TNameR,TEmailR,TPassR,TCPassR,TPhoneR;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tregister);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(this,R.color.sf));
        }
        Objects.requireNonNull(getSupportActionBar()).hide();



        TranspoterfirebaseDatabase = FirebaseDatabase.getInstance();
        Paper.init(this);

        TUserR=findViewById(R.id.T_User_R);
        TNameR=findViewById(R.id.T_fname_R);
        TEmailR=findViewById(R.id.T_Email_R);
        TPassR=findViewById(R.id.T_Pass_R);
        TCPassR=findViewById(R.id.T_CPass_R);
        TPhoneR=findViewById(R.id.T_Phone_R);

        register=findViewById(R.id.T_Register_btn);
        TvtypeR=findViewById(R.id.T_Type_R);
        TvnoR=findViewById(R.id.T_Vno_R);
        TlnoR=findViewById(R.id.T_lno_R);

        loadingbar=new ProgressDialog(this);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createAccount();
            }

            private void createAccount() {

                String tUserR=TUserR.getText().toString().trim();
                String tNameR = TNameR.getText().toString().trim();
                String tEmailR=TEmailR.getText().toString().trim();
                String tPassR=TPassR.getText().toString().trim();

                String tCPassR=TCPassR.getText().toString().trim();
                String tvtypeR=TvtypeR.getText().toString().trim();
                String tvnoR=TvnoR.getText().toString().trim();
                String tPhoneR=TPhoneR.getText().toString().trim();
                String tlnoR=TlnoR.getText().toString().trim();



                if(TextUtils.isEmpty(tUserR))
                {
                    TUserR.setError("Please enter your username");
                }
                else if(TextUtils.isEmpty(tNameR))
                {
                    TNameR.setError("Please enter your name");
                }
                else if(TextUtils.isEmpty(tEmailR))
                {
                    TEmailR.setError("Please enter your email id");
                }
                else if(TextUtils.isEmpty(tPassR))
                {
                    TPassR.setError("Please enter your password");

                }
                else if(TextUtils.isEmpty(tCPassR))
                {
                    TCPassR.setError("Please enter your password");

                }
                else if(TextUtils.isEmpty(tvtypeR))
                {
                    TvtypeR.setError("Please enter your vehicle type");

                }
                else if(TextUtils.isEmpty(tvnoR))
                {
                    TvnoR.setError("Please enter your vehicle number");

                }
                else if(TextUtils.isEmpty(tPhoneR))
                {
                    TPhoneR.setError("Please enter your phone number");

                }
                else if(TextUtils.isEmpty(tlnoR))
                {
                    TlnoR.setError("Please enter your liscence number");

                }

                else {

                    Pmodel = new ProductModel();
                    Pmodel.setSellerName(tNameR);

                    Tmodel = new TransporterModel();
                    Tmodel.settUserR(tUserR);
                    Tmodel.settNameR(tNameR);
                    Tmodel.settEmailR(tEmailR);
                    Tmodel.settPassR(tPassR);
                    Tmodel.settCPassR(tCPassR);
                    Tmodel.setTvtypeR(tvtypeR);
                    Tmodel.setTvnoR(tvnoR);
                    Tmodel.settPhoneR(tPhoneR);
                    Tmodel.setTlnoR(tlnoR);




                    loadingbar.setTitle("Register Your Account");
                    loadingbar.setMessage("Please wait,while we are checking the credentials ");
                    loadingbar.setCanceledOnTouchOutside(false);
                    loadingbar.show();

//                    auth.createUserWithEmailAndPassword(tEmailR,tPassR).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
//                        @Override
//                        public void onComplete(@NonNull Task<AuthResult> task) {
//                            if (task.isSuccessful())
//                            {
//                                Toast.makeText(T_Register.this, "Registration Successful ", Toast.LENGTH_LONG).show();
//                                tuser_number = Tmodel.gettPhoneR();
//                                Paper.book().write("phone",Tmodel.gettPhoneR());
//                                tUser_Add = Tmodel.gettUserR();
//                                Paper.book().write("User_Add",Tmodel.gettUserR());
//                                tUser_Name = Tmodel.gettEmailR();
//                                Paper.book().write("User_Name",Tmodel.gettEmailR());
//
//
//                                addtransporterDataToFireBase(Tmodel);
//                                Intent i=new Intent(getApplicationContext(), T_Login.class);
//                                startActivity(i);
//                                finish();
//                            }
//                            else
//                            {
//                                Toast.makeText(T_Register.this, "Registration Failed!!"+ Objects.requireNonNull(task.getException()).getMessage(), Toast.LENGTH_LONG).show();
//                            }
//                        }
//                    });

                }
            }
        });
            }

    private void addtransporterDataToFireBase(TransporterModel Tmodel) {
        transporterdatabaseReference = TranspoterfirebaseDatabase.getReference("TransporterRegisterModel");
        transporterdatabaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                transporterdatabaseReference.setValue(Tmodel);
                Toast.makeText(T_Register.this, "data added", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(T_Register.this, "Fail to add data " + error, Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void TRegisterpage(View v)
    {
        Intent i=new Intent(getApplicationContext(),T_Login.class);
        startActivity(i);
    }
}