package com.example.spinningfabrics.Transporter;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.spinningfabrics.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import java.util.Objects;

public class T_Login extends AppCompatActivity {
    TextView TToregister;

    FirebaseAuth auth;
    Button Tlogin;
    EditText TEmail,TPass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tlogin);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(T_Login.this,R.color.sf));
        }
        Objects.requireNonNull(getSupportActionBar()).hide();
        auth=FirebaseAuth.getInstance();
        TToregister=findViewById(R.id.T_Register);
        TEmail=findViewById(R.id.T_Email);
        TPass=findViewById(R.id.T_Pass);
        Tlogin=findViewById(R.id.T_Login);
        TToregister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)  {
                String email=TEmail.getText().toString();
                String pass=TPass.getText().toString();

//                if(!email.isEmpty() && Patterns.EMAIL_ADDRESS.matcher(email).matches())
//                {
//                    if(!pass.isEmpty())
//                    {
//
//                        loginToUser(email,pass);
//
//                    }
//                    else
//                    {
//                        TPass.setError("Password Cannot be Empty");
//                    }
//                }
//                else if(email.isEmpty())
//                {
//                    TEmail.setError("Email Cannot be Empty");
//                }
//                else
//                {
//                    TEmail.setError("Please Enter Valid Email!!");
//                }
            }
        });
    }

            private void loginToUser(String email, String pass) {

                auth.signInWithEmailAndPassword(email, pass).addOnSuccessListener(new OnSuccessListener<AuthResult>() {
                    @Override
                    public void onSuccess(AuthResult authResult) {
                        Toast.makeText(T_Login.this, "Login Successful", Toast.LENGTH_SHORT).show();
                        Intent in=new Intent(getApplicationContext(), T_Register.class);
                        startActivity(in);
                        finish();
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        Toast.makeText(T_Login.this, "Login Failed", Toast.LENGTH_SHORT).show();
            }
        });
    }

            public void ttoregister(View view)
            {
                Toast.makeText(this, "Login Successful", Toast.LENGTH_SHORT).show();
//                Intent i=new Intent(getApplicationContext(), T_Register.class);
//                startActivity(i);
                finish();
            }
    public void tregister(View view)
    {

                Intent i=new Intent(getApplicationContext(), T_Register.class);
                startActivity(i);
        finish();
    }
            
}
        