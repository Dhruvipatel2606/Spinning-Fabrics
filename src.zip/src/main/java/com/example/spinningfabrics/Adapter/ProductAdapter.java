package com.example.spinningfabrics.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.spinningfabrics.Customer.product_page;
import com.example.spinningfabrics.Model.ProductModel;
import com.example.spinningfabrics.R;

import java.util.ArrayList;

public class ProductAdapter extends RecyclerView.Adapter<ProductAdapter.ViewHolder>{

    Context context;
    ArrayList<ProductModel> list;
    public ProductAdapter(Context context, ArrayList<ProductModel> list) {
        this.context =context;
        this.list = list;
    }

    @NonNull
    @Override
    public ProductAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_list, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ProductAdapter.ViewHolder holder, int position) {
        ProductModel model = list.get(position);

        holder.material.setText("Material : "+model.getName());
        holder.sellerName.setText("Sellername : "+model.getSellerName());
        holder.price.setText("Price per meter : "+model.getPrice());
        holder.qty.setText("Stock Quantity :"+model.getQty());
        Glide.with(context).load(model.getImg()).into(holder.img);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context.getApplicationContext(), product_page.class);
                intent.putExtra("name",model.getName());
                intent.putExtra("material",model.getMaterial());
                context.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        if (list.size()>0){
            return list.size();
        }else {
            return 0;
        }

    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        ImageView img;
        TextView material,sellerName,price,qty;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            img = itemView.findViewById(R.id.img);
            material = itemView.findViewById(R.id.material);
            sellerName = itemView.findViewById(R.id.sellerName);
            price = itemView.findViewById(R.id.price);
            qty = itemView.findViewById(R.id.qty);
        }
    }
}
