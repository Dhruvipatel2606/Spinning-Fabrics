package com.example.spinningfabrics.Seller;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.content.ContextCompat;

import com.example.spinningfabrics.R;

import java.util.Objects;

public class s_new_product extends AppCompatActivity implements View.OnClickListener{

    CardView silk,chiffon,cotton,crepe,georgette,linen,organic,scrap;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_snew_product);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(s_new_product.this,R.color.white));
        }
        Objects.requireNonNull(getSupportActionBar()).hide();
        silk = findViewById(R.id.silk_card);
        chiffon = findViewById(R.id.chiffon_card);
        cotton = findViewById(R.id.cotton_card);
        crepe = findViewById(R.id.crepe_card);
        georgette = findViewById(R.id.georgette_card);
        linen = findViewById(R.id.linen_card);
        organic = findViewById(R.id.organic_card);
        scrap = findViewById(R.id.scrap_card);

        silk.setOnClickListener(this);
        chiffon.setOnClickListener(this);
        cotton.setOnClickListener(this);
        crepe.setOnClickListener(this);
        georgette.setOnClickListener(this);
        linen.setOnClickListener(this);
        organic.setOnClickListener(this);
        scrap.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId())
        {
            case R.id.silk_card:
                Intent silk = new Intent(getApplicationContext(),add_fabric.class);
                silk.putExtra("Material", "silk");
                startActivity(silk);
                break;

            case R.id.chiffon_card:
                Intent chiffon = new Intent(getApplicationContext(),add_fabric.class);
                chiffon.putExtra("Material", "chiffon");
                startActivity(chiffon);
                break;

            case R.id.cotton_card:
                Intent cotton = new Intent(getApplicationContext(),add_fabric.class);
                cotton.putExtra("Material", "cotton");
                startActivity(cotton);
                break;

            case R.id.crepe_card:
                Intent crepe = new Intent(getApplicationContext(),add_fabric.class);
                crepe.putExtra("Material", "crepe");
                startActivity(crepe);
                break;

            case R.id.georgette_card:
                Intent georgette = new Intent(getApplicationContext(),add_fabric.class);
                georgette.putExtra("Material", "georgette");
                startActivity(georgette);
                break;

            case R.id.linen_card:
                Intent linen = new Intent(getApplicationContext(),add_fabric.class);
                linen.putExtra("Material", "linen");
                startActivity(linen);
                break;

            case R.id.organic_card:
                Intent organic = new Intent(getApplicationContext(),add_fabric.class);
                organic.putExtra("Material", "organic");
                startActivity(organic);
                break;

            case R.id.scrap_card:
                Intent scrap = new Intent(getApplicationContext(),add_fabric.class);
                scrap.putExtra("Material", "scrap");
                startActivity(scrap);
                break;
        }
    }

    public void add_back(View v)
    {
        Intent back = new Intent(getApplicationContext(),S_Add.class);
        startActivity(back);
    }
}