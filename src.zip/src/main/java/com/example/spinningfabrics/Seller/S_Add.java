package com.example.spinningfabrics.Seller;

import static com.example.spinningfabrics.Constant.PRODUCT;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.spinningfabrics.Adapter.ProductAdapter;
import com.example.spinningfabrics.Model.ProductModel;
import com.example.spinningfabrics.R;
import com.example.spinningfabrics.home;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Objects;

import io.paperdb.Paper;

public class S_Add extends AppCompatActivity implements  NavigationView.OnNavigationItemSelectedListener {


    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    RecyclerView rvSellerPage;
    ImageButton s_img;
    DrawerLayout s_drawerLayout;
    NavigationView s_navigationView;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sadd);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(S_Add.this,R.color.white));
        }
        Objects.requireNonNull(getSupportActionBar()).hide();

//        Intent intent = getIntent();
//        String name = intent.getStringExtra("name");
//        String material = intent.getStringExtra("material");
//

        firebaseDatabase = FirebaseDatabase.getInstance();
        rvSellerPage = findViewById(R.id.rvSellerPage);

        Paper.init(this);
        getProduct();


        s_img=findViewById(R.id.s_menu);
        s_drawerLayout=findViewById(R.id.s_drawer_layout);
        s_navigationView=findViewById(R.id.s_navigation_view);
        navigationDrawer();

        Intent i = getIntent();

    }

    private void getProduct() {

        ArrayList<ProductModel> sellerList = new ArrayList<>();
        databaseReference = firebaseDatabase.getReference(PRODUCT);
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                sellerList.clear();
                for (DataSnapshot snapshot1 : snapshot.getChildren()) {

                    if (snapshot1 != null) {
                        for(DataSnapshot child:snapshot1.getChildren()) {
                            ProductModel model = child.getValue(ProductModel.class);
                            Log.d("TAG", "onDataChange: ====>"+model.getImg());

                            if (model != null) {
                                sellerList.add(new ProductModel(model.getImg(), model.getMaterial(), model.getName(), model.getPrice(), model.getQty(), model.getSellerName()));

                            }
                        }
                    }
                }

                LinearLayoutManager manager = new LinearLayoutManager(S_Add.this);
                ProductAdapter adapter = new ProductAdapter(S_Add.this, sellerList);
                rvSellerPage.setLayoutManager(manager);
                rvSellerPage.setAdapter(adapter);
                adapter.notifyDataSetChanged();
                Toast.makeText(S_Add.this, "data added", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(S_Add.this, "Fail to add data " + error, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void navigationDrawer() {

        s_navigationView.bringToFront();
        s_navigationView.setNavigationItemSelectedListener(this);

        s_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (s_drawerLayout.isDrawerVisible(GravityCompat.START)){
                    s_drawerLayout.closeDrawer(GravityCompat.START);
                }
                else {
                    s_drawerLayout.openDrawer(GravityCompat.START);
                }
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (s_drawerLayout.isDrawerVisible(GravityCompat.START)){
            s_drawerLayout.closeDrawer(GravityCompat.START);
        }
        else {
            super.onBackPressed();
        }
    }

    @SuppressLint("NonConstantResourceId")


    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId())
        {
            case  R.id.home:
                Toast.makeText(this, "Home Selected", Toast.LENGTH_LONG).show();
                Intent product=new Intent(getApplicationContext(),S_Add.class);
                startActivity(product);
                break;
            case  R.id.add_product:
                Toast.makeText(this, "Add Product Selected", Toast.LENGTH_LONG).show();
                Intent addproduct=new Intent(getApplicationContext(),s_new_product.class);
                startActivity(addproduct);
                break;
            case  R.id.s_profile:
                Toast.makeText(this, "My Account Selected", Toast.LENGTH_LONG).show();
                Intent profile=new Intent(getApplicationContext(),seller_profile.class);
                startActivity(profile);
                break;
            case  R.id.s_ord_list:
                Toast.makeText(this, "Order List Selected", Toast.LENGTH_LONG).show();
                Intent orderList=new Intent(getApplicationContext(),seller_product_order_list.class);
                startActivity(orderList);
                break;
            case  R.id.c_logout:
                Toast.makeText(this, "Logout Selected", Toast.LENGTH_LONG).show();
                Intent logout=new Intent(getApplicationContext(), home.class);
                FirebaseAuth.getInstance().signOut();
                startActivity(logout);
                break;
        }
       s_drawerLayout.closeDrawers();
        return true;
    }

    public void s_profile(View view)
    {
        Intent profile = new Intent(getApplicationContext(),seller_profile.class);
        startActivity(profile);
    }

    public void new_product(View view)
    {
        Intent product = new Intent(getApplicationContext(),s_new_product.class);
        startActivity(product);
//        finish();
    }

}