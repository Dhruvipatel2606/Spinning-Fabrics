package com.example.spinningfabrics.Seller;

import static com.example.spinningfabrics.Constant.SELLER_REGISTER_MODEL;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.spinningfabrics.Model.SellerRegisterModel;
import com.example.spinningfabrics.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Objects;

import io.paperdb.Paper;

public class seller_profile extends AppCompatActivity {

    FirebaseDatabase firebaseDatabase;

    DatabaseReference databaseReference;

    EditText susername, sname, semail,shop_name, sphone, sadd;
    Button s_save;

    String pass,gstno;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_seller_profile);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(seller_profile.this,R.color.white));
        }
        Objects.requireNonNull(getSupportActionBar()).hide();
        Paper.init(this);

        firebaseDatabase = FirebaseDatabase.getInstance();
        getdata();

        susername = findViewById(R.id.s_username);
        sname = findViewById(R.id.s_name);
        semail = findViewById(R.id.s_email);
        shop_name = findViewById(R.id.shop_name);
        sphone = findViewById(R.id.s_phone);
        sadd = findViewById(R.id.s_add);
        s_save = findViewById(R.id.s_save);

        shop_name.setEnabled(false);
        sname.setEnabled(false);
        semail.setEnabled(false);

        s_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String suser, name, email, phone, add,shopname;
                suser = susername.getText().toString();
                name = sname.getText().toString();
                email = semail.getText().toString();
                shopname = shop_name.getText().toString();
                phone = sphone.getText().toString();
                add = sadd.getText().toString();

                SellerRegisterModel Smodel = new SellerRegisterModel();
                Smodel.setUsername(suser);
                Smodel.setName(name);
                Smodel.setEmail(email);
                Smodel.setPass(pass);
                Smodel.setAddress(add);
                Smodel.setPhone(phone);
                Smodel.setShopname(shopname);
                Smodel.setGstno(gstno);



                databaseReference = firebaseDatabase.getReference(SELLER_REGISTER_MODEL).child(Paper.book().read("GST").toString());
                databaseReference.addValueEventListener(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        databaseReference.setValue(Smodel);
                        Toast.makeText(seller_profile.this, "detail save successfully", Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {
//                Toast.makeText(profile.this, "Fail to get data.", Toast.LENGTH_SHORT).show();
                    }
                });

            }
        });
    }

    private void getdata() {

        databaseReference = firebaseDatabase.getReference(SELLER_REGISTER_MODEL).child(Paper.book().read("GST").toString());

        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                SellerRegisterModel Smodel = snapshot.getValue(SellerRegisterModel.class);
                if (Smodel != null) {
                    susername.setText(Smodel.getUsername());
                    sname.setText(Smodel.getName());
                    semail.setText(Smodel.getEmail());
                    sphone.setText(Smodel.getPhone());
                    sadd.setText(Smodel.getAddress());
                    shop_name.setText(Smodel.getShopname());
                    pass = Smodel.getPass();
                    gstno=Smodel.getGstno();

                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
//                Toast.makeText(profile.this, "Fail to get data.", Toast.LENGTH_SHORT).show();
            }
        });
    }


    public void logout(View view) {
        FirebaseAuth.getInstance().signOut();
        Intent home = new Intent(getApplicationContext(), com.example.spinningfabrics.home.class);
        startActivity(home);

    }

    public void seller_profile_back(View view)
    {
        Intent back = new Intent(getApplicationContext(), S_Add.class);
        startActivity(back);
        //finish();
    }
}