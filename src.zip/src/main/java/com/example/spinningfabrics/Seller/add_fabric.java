package com.example.spinningfabrics.Seller;

import static com.example.spinningfabrics.Constant.PRODUCT;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.spinningfabrics.Model.ProductModel;
import com.example.spinningfabrics.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.util.Objects;

import io.paperdb.Paper;

public class add_fabric extends AppCompatActivity {
    private static final int PICK_IMAGE = 100;
    Uri imageUri;
    EditText p_price, p_material, p_total_stock, p_name;
    ImageView imgpick;
    Button btnAddProduct;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    FirebaseStorage storage;
    String material,name,stock,price,img;
    StorageReference storageReference;

    public static String PRICE;

    public boolean isImageSelected = false;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_fabric);
        firebaseDatabase = FirebaseDatabase.getInstance();
        // get the Firebase  storage reference
        storage = FirebaseStorage.getInstance();
        storageReference = storage.getReference();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(add_fabric.this, R.color.white));
        }
        Objects.requireNonNull(getSupportActionBar()).hide();

        imgpick = findViewById(R.id.imgpick);
        p_price = findViewById(R.id.p_price);
        p_material = findViewById(R.id.p_material);
        p_total_stock = findViewById(R.id.p_total_stock);
        p_name = findViewById(R.id.p_name);
        btnAddProduct = findViewById(R.id.btnAddProduct);


        p_material.setEnabled(false);
        btnAddProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                name = p_name.getText().toString();
                stock = p_total_stock.getText().toString();
                material = p_material.getText().toString();
                price = p_price.getText().toString();
                img = imageUri.toString();
                boolean isUploaded = uploadImage(imageUri, material, name);

            }
        });

        Intent i = getIntent();
        String name = i.getStringExtra("Material");
        p_material.setText("" + name);
    }

    private void addToFireBase(Uri downLoadUrl) {
        databaseReference = firebaseDatabase.getReference(PRODUCT).child(material).child(name);
        Log.d("TAG", "onClick: ====> databaseReference : " + databaseReference.toString());
        databaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                ProductModel model = new ProductModel();
                model.setName(name);
                model.setQty(stock);
                model.setPrice(price);
                model.setMaterial(material);
                model.setImg(downLoadUrl.toString());
                model.setSellerName(Paper.book().read("sellerName"));
                databaseReference.setValue(model);
                Toast.makeText(getApplicationContext(), "add successfully ", Toast.LENGTH_SHORT).show();
                PRICE = model.getPrice();
                Paper.book().write("PRICE",model.getPrice());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.d("TAG", "onCancelled: ====> error : " + error.getMessage());
            }
        });
    }


    private void getUrlAsync(String material, String name) {
        // Points to the root reference
        StorageReference dateRef = storageReference.child(material + "/" + name);
        dateRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
            @Override
            public void onSuccess(Uri downloadUrl) {
               addToFireBase(downloadUrl);
            }
        });
    }

    private boolean uploadImage(Uri filePath, String material, String name) {
        if (filePath != null) {

            // Code for showing progressDialog while uploading
            ProgressDialog progressDialog = new ProgressDialog(this);
            progressDialog.setTitle("Uploading...");
            progressDialog.show();

            // Defining the child of storageReference
            StorageReference ref = storageReference.child(material + "/" + name);

            // adding listeners on upload
            // or failure of image
            ref.putFile(filePath)
                    .addOnSuccessListener(
                            new OnSuccessListener<UploadTask.TaskSnapshot>() {
                                @Override
                                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                                    // Image uploaded successfully
                                    // Dismiss dialog
                                    progressDialog.dismiss();
                                    getUrlAsync(material,name);
                                    Toast.makeText(add_fabric.this, "Image Uploaded!!", Toast.LENGTH_SHORT).show();
                                }
                            })

                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {

                            // Error, Image not uploaded
                            progressDialog.dismiss();
                            Toast.makeText(add_fabric.this, "Failed " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnProgressListener(new OnProgressListener<UploadTask.TaskSnapshot>() {

                        // Progress Listener for loading
                        // percentage on the dialog box
                        @Override
                        public void onProgress(UploadTask.TaskSnapshot taskSnapshot) {
                            double progress = (100.0 * taskSnapshot.getBytesTransferred() / taskSnapshot.getTotalByteCount());progressDialog.setMessage("Uploaded " + (int) progress + "%");
                        }
                    });

        }
        return true;
    }

    public void image(View v) {
        if (!isImageSelected) {
            imageChooser();
        }
    }

    private void imageChooser() {
        Intent gallery = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.INTERNAL_CONTENT_URI);
        startActivityForResult(gallery, PICK_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && requestCode == PICK_IMAGE) {
            imageUri = data.getData();
            imgpick.setImageURI(imageUri);

            isImageSelected = true;

        }
    }

}