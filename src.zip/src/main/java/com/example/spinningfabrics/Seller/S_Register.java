package com.example.spinningfabrics.Seller;


import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.spinningfabrics.Model.ProductModel;
import com.example.spinningfabrics.Model.SellerRegisterModel;
import com.example.spinningfabrics.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.Objects;

import io.paperdb.Paper;

public class S_Register extends AppCompatActivity{
    Button STologin;
    ProgressDialog loadingbar;
    FirebaseDatabase SellerfirebaseDatabase;
    DatabaseReference sellerdatabaseReference;
    EditText SUserR,SEmailR,SPassR,SShopR,SgstR,SAddR,SPhoneR,SnameR;
    SellerRegisterModel Smodel;
    ProductModel Pmodel;
    public static String GST,SellerName;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sregister);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(this,R.color.sf));
        }
        Objects.requireNonNull(getSupportActionBar()).hide();

        SellerfirebaseDatabase = FirebaseDatabase.getInstance();
        Paper.init(this);

        STologin=findViewById(R.id.S_Register_btn);
        SUserR=findViewById(R.id.S_User_R);
        SnameR=findViewById(R.id.S_name);
        SEmailR=findViewById(R.id.S_Email_R);
        SPassR=findViewById(R.id.S_Pass_R);

        SShopR=findViewById(R.id.S_Shop_R);
        SgstR=findViewById(R.id.S_GST_R);
        SAddR=findViewById(R.id.S_Add_R);
        SPhoneR=findViewById(R.id.S_Phone_R);

        loadingbar=new ProgressDialog(this);

        STologin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                createAccount();
            }

            private void createAccount() {
                String suser=SUserR.getText().toString().trim();
                String sname = SnameR.getText().toString().trim();
                String semail=SEmailR.getText().toString().trim();
                String spass=SPassR.getText().toString().trim();

                String sshop=SShopR.getText().toString().trim();
                String sgst=SgstR.getText().toString().trim();
                String sadd=SAddR.getText().toString().trim();
                String sphone=SPhoneR.getText().toString().trim();


                if(TextUtils.isEmpty(suser))
                {
                    SUserR.setError("Please enter your username");
                }
                else if(TextUtils.isEmpty(sname))
                {
                    SnameR.setError("Please enter your name");
                }
                else if(TextUtils.isEmpty(semail))
                {
                    SEmailR.setError("Please enter your email id");
                }
                else if(TextUtils.isEmpty(spass))
                {
                    SPassR.setError("Please enter your password");

                }

                else if(TextUtils.isEmpty(sadd))
                {
                    SAddR.setError("Please enter your address");

                }
                else if(TextUtils.isEmpty(sshop))
                {
                    SShopR.setError("Please enter your city");

                }
                else if(TextUtils.isEmpty(sgst))
                {
                    SgstR.setError("Please enter your state");

                }
                else if(TextUtils.isEmpty(sphone))
                {
                    SPhoneR.setError("Please enter your phone number");

                }

                else {

                    Pmodel = new ProductModel();
                    Pmodel.setSellerName(sname);

                    Smodel = new SellerRegisterModel();
                    Smodel.setUsername(suser);
                    Smodel.setName(sname);
                    Smodel.setEmail(semail);
                    Smodel.setPass(spass);
                    Smodel.setAddress(sadd);
                    Smodel.setPhone(sphone);
                    Smodel.setShopname(sshop);
                    Smodel.setGstno(sgst);



                    loadingbar.setTitle("Register Your Account");
                    loadingbar.setMessage("Please wait,while we are checking the credentials ");
                    loadingbar.setCanceledOnTouchOutside(false);
                    loadingbar.show();
                    Intent i=new Intent(getApplicationContext(),S_Login.class);
                    startActivity(i);

//                    SellerName = Smodel.getName();
//                    Paper.book().write("sellerName",Smodel.getName());

                    GST = Smodel.getGstno();
                    Paper.book().write("GST",Smodel.getGstno());
                    addSellerDataToFireBase(Smodel);
                }
            }
        });
    }



    private void addSellerDataToFireBase(SellerRegisterModel Smodel) {
        sellerdatabaseReference = SellerfirebaseDatabase.getReference("SellerRegisterModel").child(GST);
        sellerdatabaseReference.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                GST = Smodel.getGstno();
                sellerdatabaseReference.setValue(Smodel);
                Toast.makeText(S_Register.this, "data added", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(S_Register.this, "Fail to add data " + error, Toast.LENGTH_SHORT).show();
            }
        });
    }
}