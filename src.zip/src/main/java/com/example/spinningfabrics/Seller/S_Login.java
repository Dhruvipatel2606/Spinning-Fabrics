package com.example.spinningfabrics.Seller;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example.spinningfabrics.R;

import java.util.Objects;

public class S_Login extends AppCompatActivity implements View.OnClickListener {
    TextView SToregister;
    Button Slogin;
    EditText SEmail;
    EditText SPass;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slogin);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(S_Login.this, R.color.sf));
        }
        Objects.requireNonNull(getSupportActionBar()).hide();
        SToregister = findViewById(R.id.S_Register);

        SEmail = findViewById(R.id.S_Email);
        SPass = findViewById(R.id.S_Pass);
        Slogin = findViewById(R.id.S_Login);
        SToregister.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        Intent i = new Intent(getApplicationContext(), S_Register.class);
        startActivity(i);
    }

    public void tologin(View view) {
        Intent in = new Intent(getApplicationContext(), S_Add.class);
        startActivity(in);
    }
}