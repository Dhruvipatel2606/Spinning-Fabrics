package com.example.spinningfabrics;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.spinningfabrics.Customer.C_Login;
import com.example.spinningfabrics.Customer.Gallery;
import com.example.spinningfabrics.Seller.S_Login;
import com.example.spinningfabrics.Transporter.T_Login;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.Objects;

public class home extends AppCompatActivity {


    FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            getWindow().setStatusBarColor(ContextCompat.getColor(home.this, R.color.sf));
        }
        Objects.requireNonNull(getSupportActionBar()).hide();

        auth = FirebaseAuth.getInstance();
        EnableRuntimePermission();

    }

    private void EnableRuntimePermission() {
        if (ActivityCompat.shouldShowRequestPermissionRationale(home.this, Manifest.permission.READ_EXTERNAL_STORAGE)) {
            Toast.makeText(home.this, "This app has been granted READ EXTERNAL STORAGE permission", Toast.LENGTH_LONG).show();
        } else {
            ActivityCompat.requestPermissions(home.this, new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 100);
        }
    }

    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case 100:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(home.this, "Permission Granted",Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(home.this, "Permission Cancelled",Toast.LENGTH_LONG).show();
                }
                break;
        }
    }

    public void CustomerButton(View v) {

        auth.addAuthStateListener(new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
                if (user != null) {
                    Intent i = new Intent(getApplicationContext(), Gallery.class);
                    startActivity(i);
                    finish();
                } else {
                    Intent CustomerInt = new Intent(getApplicationContext(), C_Login.class);
                    startActivity(CustomerInt);
                    finish();
                }
            }
        });

    }

    public void SellerButton(View v) {
        Intent SellerInt = new Intent(this, S_Login.class);
        startActivity(SellerInt);
    }

    public void TransporterButton(View v) {
        Intent TransporterInt = new Intent(this, T_Login.class);
        startActivity(TransporterInt);
    }


}